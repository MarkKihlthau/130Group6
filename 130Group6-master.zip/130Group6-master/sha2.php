<!DOCTYPE html>
<html>
<body>

<?php
echo "This will run the SHA2.";
?>

</body>
</html>
