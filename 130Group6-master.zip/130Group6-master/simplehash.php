<!DOCTYPE html>
<html>
<body>

<?php
echo "This will be the simple hash.";
?>

</body>
</html>
